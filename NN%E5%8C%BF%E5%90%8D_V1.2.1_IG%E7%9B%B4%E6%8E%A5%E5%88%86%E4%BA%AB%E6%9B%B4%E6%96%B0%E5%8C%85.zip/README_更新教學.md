# NN匿名 V1.2.1｜iPhone IG 直接分享（不必先下載 PNG）

## 新增功能
- 在原本「IG 貼文圖片預覽」中新增「分享到 Instagram／其他 App」。
- 點擊後使用 iOS 系統分享介面傳送圖片，不經由檔案 App 先行下載。
- 另有「分享全部頁面」按鈕，供多張圖分享（是否支援取決於 Instagram）。
- 「複製 IG 文案」協助將原本投稿文案貼到 Instagram。
- 保留「下載本頁 PNG（備用）」以兼容不支援直接分享的瀏覽器。

## 安裝方式
1. 先從 GitHub 下載並備份現有 admin-publish.html。
2. 將此資料夾的 admin-publish.html 上傳到 nn-anonymous/nn-anonymous 的 main 分支根目錄，覆蓋同名檔。
3. 確認 GitHub Pages 更新後，用 iPhone Safari 開啟 https://nn-anonymous.github.io/nn-anonymous/admin-publish.html
4. 登入原有 NN匿名管理員帳號，找到已編號投稿，展開「Instagram 貼文管理」。
5. 按「預覽／直接分享 IG 圖片」→「分享到 Instagram／其他 App」→ 在 iOS 分享選單選擇可用的 Instagram 項目，於 Instagram 完成發文。

## 已知限制
- 這是 iOS 系統分享，不是 Instagram Graph API 自動發文；無法保證分享選單必定出現 Instagram「貼文」。
- Instagram App 可能不支援多張檔案同時從網頁分享；可改用單張分享或備用下載。
- 分享圖片時 IG 可能不會自動帶入 caption，請先按「複製 IG 文案」。
- 在 ChatGPT 或其他 App 內建瀏覽器不一定支援，優先使用 Safari。
- 分享不代表已實際發布，只有在 IG 確認發文後才點後台「標記已發布到 IG」。
- 不更動任何 Supabase API、登入、審核、已分配編號、網站發布/下架、儲存 IG 草稿邏輯。
- 請勿把任何私密 Supabase service_role key 或 Turnstile Secret Key 放進前端。
